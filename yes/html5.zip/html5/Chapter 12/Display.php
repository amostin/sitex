<?php
$file = $_GET['code'];

echo highlight_file($file, 1);
?> 