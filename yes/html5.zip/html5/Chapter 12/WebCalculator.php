<?php
       $num1 = $_GET['number1'];
       $num2 = $_GET['number2'];
echo ($num1 + $num2); 

?>
