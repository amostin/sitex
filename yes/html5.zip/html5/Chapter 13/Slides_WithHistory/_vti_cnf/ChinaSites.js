vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|29 Jul 2011 01:15:11 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|Matthew-PC\\matthew
vti_modifiedby:SR|Matthew-PC\\matthew
vti_nexttolasttimemodified:TR|22 Jul 2011 20:33:13 -0000
vti_timecreated:TR|29 Jul 2011 01:15:11 -0000
vti_cacheddtm:TX|29 Jul 2011 01:15:11 -0000
vti_filesize:IR|1127
vti_backlinkinfo:VX|html5/Chapter\\ 12/Slides_WithHistory/ChinaSites.html html5/Chapter\\ 12/Slides_WithHistory/ChinaSites5.html html5/Chapter\\ 12/Slides_WithHistory/ChinaSites3.html html5/Chapter\\ 12/Slides_WithHistory/ChinaSites1.html html5/Chapter\\ 12/Slides_WithHistory/ChinaSites4.html html5/Chapter\\ 12/Slides_WithHistory/ChinaSites2.html
vti_syncofs_www.reboot-me.com\:21/www/prosetech:TW|05 Aug 2011 18:44:37 -0000
vti_syncwith_www.reboot-me.com\:21/www/prosetech:TX|29 Jul 2011 01:15:11 -0000
