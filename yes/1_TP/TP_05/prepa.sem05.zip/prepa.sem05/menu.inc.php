<?php
/**
 * Created by PhpStorm.
 * User: Moi
 * Date: 13/03/2019
 * Time: 07:58
 *
 */

//include_once "demoSession.css"
?>
<!doctype html>
    <head>
    <link rel="stylesheet" href="demoSession.css">
    </head>
    <body>
        <nav id="menu">MENU
            <li><a href="demoSession01start.php">start</a></li>
            <li><a href="demoSession02get01.php">get</a></li>
            <li><a href="demoSession02get02.php">print_r</a></li>
            <li><a href="demoSession03modify.php">modify</a></li>
            <li><a href="demoSession04destroy.php">destroy</a></li>
        </nav>
    </body>
</html>
